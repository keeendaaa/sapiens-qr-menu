
  # Restaurant Web App Menu

  This is a code bundle for Restaurant Web App Menu. The original project is available at https://www.figma.com/design/w5tZjTVoOQRViI9zwHIVC0/Restaurant-Web-App-Menu.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  